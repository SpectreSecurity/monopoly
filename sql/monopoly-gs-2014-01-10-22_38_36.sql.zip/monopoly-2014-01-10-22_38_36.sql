-- phpMyAdmin SQL Dump
-- version 3.5.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 10, 2014 at 10:38 PM
-- Server version: 5.5.28
-- PHP Version: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `monopoly`
--

-- --------------------------------------------------------

--
-- Table structure for table `gw_users`
--

CREATE TABLE IF NOT EXISTS `gw_users` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(240) NOT NULL,
  `u_login` varchar(240) NOT NULL,
  `u_password` char(32) DEFAULT NULL,
  `service` varchar(240) DEFAULT NULL,
  `identity` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_auaction`
--

CREATE TABLE IF NOT EXISTS `m_cfg_auaction` (
  `auact_code` int(11) NOT NULL,
  `auact_desc` varchar(2000) COLLATE utf8_bin NOT NULL,
  `auact_sql_tpl` text COLLATE utf8_bin NOT NULL,
  `auact_msg_tpl_code` varchar(240) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`auact_code`),
  KEY `auact_msg_tpl_code` (`auact_msg_tpl_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_faction`
--

CREATE TABLE IF NOT EXISTS `m_cfg_faction` (
  `fact_code` int(11) NOT NULL,
  `fact_desc` varchar(2000) COLLATE cp1251_general_cs NOT NULL,
  `event` enum('onfly','onsite') COLLATE cp1251_general_cs NOT NULL,
  `fact_sql_tpl` text COLLATE cp1251_general_cs NOT NULL,
  `fact_msg_tpl` text COLLATE cp1251_general_cs,
  PRIMARY KEY (`fact_code`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_ftype`
--

CREATE TABLE IF NOT EXISTS `m_cfg_ftype` (
  `ftype_code` int(11) NOT NULL,
  `field_desc` varchar(2000) COLLATE cp1251_general_cs DEFAULT NULL,
  UNIQUE KEY `ftype_code` (`ftype_code`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_language`
--

CREATE TABLE IF NOT EXISTS `m_cfg_language` (
  `lang_code` varchar(240) COLLATE utf8_bin NOT NULL,
  `lang_name` varchar(240) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`lang_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_map`
--

CREATE TABLE IF NOT EXISTS `m_cfg_map` (
  `map_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(2000) COLLATE cp1251_general_cs NOT NULL,
  PRIMARY KEY (`map_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_map_fgroup`
--

CREATE TABLE IF NOT EXISTS `m_cfg_map_fgroup` (
  `fgroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `fgroup_name` varchar(240) COLLATE utf8_bin NOT NULL,
  `fgparam` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`fgroup_id`),
  KEY `map_id` (`map_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=210 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_map_field`
--

CREATE TABLE IF NOT EXISTS `m_cfg_map_field` (
  `field_id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `fcode` int(11) NOT NULL,
  `name` varchar(2000) COLLATE cp1251_general_cs NOT NULL,
  `ftype_code` int(11) NOT NULL,
  `fgroup_id` int(11) DEFAULT NULL,
  `fact_code` int(11) DEFAULT NULL,
  `fact_cond` varchar(1000) COLLATE cp1251_general_cs DEFAULT NULL,
  `fparam` varchar(240) COLLATE cp1251_general_cs DEFAULT NULL,
  `fparam_calc1` varchar(1000) COLLATE cp1251_general_cs DEFAULT NULL,
  `fparam_calc2` varchar(1000) COLLATE cp1251_general_cs DEFAULT NULL,
  PRIMARY KEY (`field_id`),
  KEY `ftype_code` (`ftype_code`),
  KEY `map_id` (`map_id`),
  KEY `fgroup_id` (`fgroup_id`),
  KEY `fact_code` (`fact_code`),
  KEY `fgroup_id_2` (`fgroup_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs AUTO_INCREMENT=233 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_message`
--

CREATE TABLE IF NOT EXISTS `m_cfg_message` (
  `msg_code` varchar(240) COLLATE utf8_bin NOT NULL,
  `msg_desc` text COLLATE utf8_bin NOT NULL,
  `msg_class` enum('au','gm','gn','dl') COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`msg_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_message_lang`
--

CREATE TABLE IF NOT EXISTS `m_cfg_message_lang` (
  `msgl_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_code` varchar(240) COLLATE utf8_bin NOT NULL,
  `lang_code` varchar(240) COLLATE utf8_bin NOT NULL,
  `msg` text COLLATE utf8_bin NOT NULL,
  `is_tpl` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msgl_id`),
  UNIQUE KEY `msg_code` (`msg_code`,`lang_code`),
  KEY `lang_code` (`lang_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=33 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_cfg_saction`
--

CREATE TABLE IF NOT EXISTS `m_cfg_saction` (
  `sact_code` int(11) NOT NULL,
  `sact_desc` varchar(2000) COLLATE cp1251_general_cs NOT NULL,
  `chance` int(11) NOT NULL,
  `sact_sql_tpl` text COLLATE cp1251_general_cs NOT NULL,
  PRIMARY KEY (`sact_code`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession`
--

CREATE TABLE IF NOT EXISTS `m_gsession` (
  `gsession_id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `createstamp` timestamp NULL DEFAULT NULL,
  `startstamp` timestamp NULL DEFAULT NULL,
  `endstamp` timestamp NULL DEFAULT NULL,
  `gstatus` int(11) NOT NULL,
  `gstate` tinyint(4) NOT NULL,
  `gturn` int(11) NOT NULL,
  `creator_user_id` int(11) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`gsession_id`),
  KEY `map_id` (`map_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs AUTO_INCREMENT=63 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_auction`
--

CREATE TABLE IF NOT EXISTS `m_gsession_auction` (
  `auct_id` int(11) NOT NULL AUTO_INCREMENT,
  `gsession_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `auct_state` enum('opened','closed') COLLATE utf8_bin NOT NULL,
  `auct_status` tinyint(4) NOT NULL,
  `auct_type` tinyint(4) NOT NULL,
  `auct_bid` int(11) NOT NULL,
  `auct_holder_user_id` int(11) DEFAULT NULL,
  `auct_bid_user_id` int(11) DEFAULT NULL,
  `auct_step` int(11) NOT NULL,
  `auct_startstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `auct_laststamp` timestamp NULL DEFAULT NULL,
  `auct_endstamp` timestamp NULL DEFAULT NULL,
  `last_changed` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`auct_id`),
  UNIQUE KEY `uk_auction_filed` (`gsession_id`,`field_id`,`auct_endstamp`),
  KEY `gsession_id` (`gsession_id`),
  KEY `field_id` (`field_id`),
  KEY `auct_bid_user` (`auct_bid_user_id`),
  KEY `auct_holder_user_id` (`auct_holder_user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=94749 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_auction_bid`
--

CREATE TABLE IF NOT EXISTS `m_gsession_auction_bid` (
  `gsession_id` int(11) NOT NULL,
  `auct_id` int(11) NOT NULL,
  `bidder_user_id` int(11) DEFAULT NULL,
  `bid` int(11) NOT NULL,
  `auct_step` int(11) NOT NULL,
  `auct_step_type` enum('bid','end') COLLATE utf8_bin NOT NULL,
  `auct_stepstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `IX_AUCTION_STEP` (`auct_id`,`auct_step`),
  KEY `gsession_id` (`gsession_id`),
  KEY `bidder_user_id` (`bidder_user_id`),
  KEY `auct_id` (`auct_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_auction_user`
--

CREATE TABLE IF NOT EXISTS `m_gsession_auction_user` (
  `auct_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `auct_user_state` enum('on','off') COLLATE utf8_bin NOT NULL,
  `last_bid` int(11) DEFAULT NULL,
  UNIQUE KEY `IX_AUCT_USER` (`auct_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_deal`
--

CREATE TABLE IF NOT EXISTS `m_gsession_deal` (
  `deal_id` int(11) NOT NULL AUTO_INCREMENT,
  `gsession_id` int(11) NOT NULL,
  `deal_holder_user_id` int(11) NOT NULL,
  `deal_opponent_user_id` int(11) NOT NULL,
  `deal_status` tinyint(4) NOT NULL,
  `deal_state` enum('opened','rejected','accepted','terminated','canceled') COLLATE utf8_bin NOT NULL,
  `deal_startstamp` timestamp NULL DEFAULT NULL,
  `deal_endstamp` timestamp NULL DEFAULT NULL,
  `deal_payment` int(11) DEFAULT NULL,
  `last_changed` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`deal_id`),
  KEY `deal_holder_user_id` (`deal_holder_user_id`),
  KEY `deal_user_id` (`deal_opponent_user_id`),
  KEY `gsession_id` (`gsession_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=42 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_deal_list`
--

CREATE TABLE IF NOT EXISTS `m_gsession_deal_list` (
  `deal_id` int(11) NOT NULL,
  `ddirection` enum('give','receive') COLLATE utf8_bin NOT NULL,
  `field_id` int(11) NOT NULL,
  KEY `deal_id` (`deal_id`),
  KEY `field_id` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_log`
--

CREATE TABLE IF NOT EXISTS `m_gsession_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `gsession_id` int(11) NOT NULL,
  `loglevel` int(11) NOT NULL DEFAULT '1',
  `user_id` int(11) DEFAULT NULL,
  `action_desc` varchar(1000) COLLATE cp1251_general_cs DEFAULT NULL,
  `datestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `microtime` bigint(11) NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `gsession_id` (`gsession_id`),
  KEY `user_id` (`user_id`),
  KEY `datestamp` (`datestamp`),
  KEY `microtime` (`microtime`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs AUTO_INCREMENT=3844038 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_map_fgroup`
--

CREATE TABLE IF NOT EXISTS `m_gsession_map_fgroup` (
  `gsession_id` int(11) NOT NULL,
  `map_id` int(11) NOT NULL,
  `fgroup_id` int(11) NOT NULL,
  `fgowner_user_id` int(11) DEFAULT NULL,
  `fgparam` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  UNIQUE KEY `UK_GS_FG_ID` (`gsession_id`,`fgroup_id`),
  KEY `gsession_id` (`gsession_id`),
  KEY `fgroup_id` (`fgroup_id`),
  KEY `map_id` (`map_id`),
  KEY `fgowner_user_id` (`fgowner_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_map_field`
--

CREATE TABLE IF NOT EXISTS `m_gsession_map_field` (
  `gsession_id` int(11) NOT NULL,
  `map_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `fgroup_id` int(11) DEFAULT NULL,
  `fparam` varchar(240) COLLATE cp1251_general_cs DEFAULT NULL,
  `fparam_calc1` varchar(1000) COLLATE cp1251_general_cs DEFAULT NULL,
  `fparam_calc2` varchar(1000) COLLATE cp1251_general_cs DEFAULT NULL,
  `owner_user_id` int(11) DEFAULT NULL,
  `fauct_id` int(11) DEFAULT NULL,
  `fdeal_id` int(11) DEFAULT NULL,
  `last_changed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `ix_gsession_map_field` (`gsession_id`,`field_id`),
  UNIQUE KEY `fauct_id` (`fauct_id`),
  UNIQUE KEY `fdeal_id` (`fdeal_id`),
  KEY `gsession_id` (`gsession_id`),
  KEY `map_id` (`map_id`),
  KEY `field_id` (`field_id`),
  KEY `owner_user_id` (`owner_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_msg`
--

CREATE TABLE IF NOT EXISTS `m_gsession_msg` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `datestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gsession_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `msgtype` tinyint(4) NOT NULL,
  `msg_text` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`msg_id`),
  KEY `user_id` (`user_id`),
  KEY `gsession_id` (`gsession_id`),
  KEY `datestamp` (`datestamp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2810754 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_gsession_user`
--

CREATE TABLE IF NOT EXISTS `m_gsession_user` (
  `gsu_id` int(11) NOT NULL AUTO_INCREMENT,
  `gsession_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `act_order` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_holder` tinyint(1) NOT NULL DEFAULT '0',
  `has_penalty` tinyint(1) NOT NULL DEFAULT '0',
  `penalty_turn` int(11) DEFAULT NULL,
  `user_cash` int(11) NOT NULL,
  `position_field_id` int(11) NOT NULL,
  `last_dice1` tinyint(4) DEFAULT NULL,
  `last_dice2` tinyint(4) DEFAULT NULL,
  `debitor_stamp` timestamp NULL DEFAULT NULL,
  `last_changed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`gsu_id`),
  UNIQUE KEY `UK_GSESSION_USER` (`gsession_id`,`user_id`),
  KEY `gsession_id` (`gsession_id`),
  KEY `user_id` (`user_id`),
  KEY `position_field_id` (`position_field_id`),
  KEY `act_order` (`act_order`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs AUTO_INCREMENT=106 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_user`
--

CREATE TABLE IF NOT EXISTS `m_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id user',
  `login` varchar(240) COLLATE cp1251_general_cs NOT NULL COMMENT 'login',
  `name` varchar(1000) COLLATE cp1251_general_cs NOT NULL,
  `passwd` varchar(240) COLLATE cp1251_general_cs NOT NULL,
  `service` varchar(240) COLLATE cp1251_general_cs NOT NULL,
  `identity` varchar(2000) COLLATE cp1251_general_cs NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_general_cs AUTO_INCREMENT=31 ;

-- --------------------------------------------------------

--
-- Table structure for table `m_watchdog`
--

CREATE TABLE IF NOT EXISTS `m_watchdog` (
  `w_id` int(11) NOT NULL AUTO_INCREMENT,
  `watch_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `wstatus` enum('finished','inprogress','failed') COLLATE utf8_bin NOT NULL,
  `wstart_stamp` timestamp NULL DEFAULT NULL,
  `wend_stamp` timestamp NULL DEFAULT NULL,
  `wspend` float DEFAULT NULL,
  PRIMARY KEY (`w_id`),
  UNIQUE KEY `watch_stamp` (`watch_stamp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=807568 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `m_cfg_auaction`
--
ALTER TABLE `m_cfg_auaction`
  ADD CONSTRAINT `m_cfg_auaction_ibfk_1` FOREIGN KEY (`auact_msg_tpl_code`) REFERENCES `m_cfg_message` (`msg_code`);

--
-- Constraints for table `m_cfg_map_fgroup`
--
ALTER TABLE `m_cfg_map_fgroup`
  ADD CONSTRAINT `m_cfg_map_fgroup_ibfk_1` FOREIGN KEY (`map_id`) REFERENCES `m_cfg_map` (`map_id`);

--
-- Constraints for table `m_cfg_map_field`
--
ALTER TABLE `m_cfg_map_field`
  ADD CONSTRAINT `m_cfg_map_field_ibfk_1` FOREIGN KEY (`map_id`) REFERENCES `m_cfg_map` (`map_id`),
  ADD CONSTRAINT `m_cfg_map_field_ibfk_2` FOREIGN KEY (`ftype_code`) REFERENCES `m_cfg_ftype` (`ftype_code`),
  ADD CONSTRAINT `m_cfg_map_field_ibfk_3` FOREIGN KEY (`fact_code`) REFERENCES `m_cfg_faction` (`fact_code`),
  ADD CONSTRAINT `m_cfg_map_field_ibfk_4` FOREIGN KEY (`fgroup_id`) REFERENCES `m_cfg_map_fgroup` (`fgroup_id`);

--
-- Constraints for table `m_cfg_message_lang`
--
ALTER TABLE `m_cfg_message_lang`
  ADD CONSTRAINT `m_cfg_message_lang_ibfk_1` FOREIGN KEY (`msg_code`) REFERENCES `m_cfg_message` (`msg_code`),
  ADD CONSTRAINT `m_cfg_message_lang_ibfk_2` FOREIGN KEY (`lang_code`) REFERENCES `m_cfg_language` (`lang_code`);

--
-- Constraints for table `m_gsession`
--
ALTER TABLE `m_gsession`
  ADD CONSTRAINT `m_gsession_ibfk_1` FOREIGN KEY (`map_id`) REFERENCES `m_cfg_map` (`map_id`);

--
-- Constraints for table `m_gsession_auction`
--
ALTER TABLE `m_gsession_auction`
  ADD CONSTRAINT `m_gsession_auction_ibfk_1` FOREIGN KEY (`gsession_id`) REFERENCES `m_gsession` (`gsession_id`),
  ADD CONSTRAINT `m_gsession_auction_ibfk_2` FOREIGN KEY (`field_id`) REFERENCES `m_cfg_map_field` (`field_id`),
  ADD CONSTRAINT `m_gsession_auction_ibfk_3` FOREIGN KEY (`auct_bid_user_id`) REFERENCES `m_user` (`user_id`),
  ADD CONSTRAINT `m_gsession_auction_ibfk_4` FOREIGN KEY (`auct_holder_user_id`) REFERENCES `m_user` (`user_id`);

--
-- Constraints for table `m_gsession_auction_bid`
--
ALTER TABLE `m_gsession_auction_bid`
  ADD CONSTRAINT `m_gsession_auction_bid_ibfk_1` FOREIGN KEY (`gsession_id`) REFERENCES `m_gsession` (`gsession_id`),
  ADD CONSTRAINT `m_gsession_auction_bid_ibfk_2` FOREIGN KEY (`auct_id`) REFERENCES `m_gsession_auction` (`auct_id`),
  ADD CONSTRAINT `m_gsession_auction_bid_ibfk_3` FOREIGN KEY (`bidder_user_id`) REFERENCES `m_user` (`user_id`);

--
-- Constraints for table `m_gsession_auction_user`
--
ALTER TABLE `m_gsession_auction_user`
  ADD CONSTRAINT `m_gsession_auction_user_ibfk_1` FOREIGN KEY (`auct_id`) REFERENCES `m_gsession_auction` (`auct_id`),
  ADD CONSTRAINT `m_gsession_auction_user_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `m_user` (`user_id`);

--
-- Constraints for table `m_gsession_deal`
--
ALTER TABLE `m_gsession_deal`
  ADD CONSTRAINT `m_gsession_deal_ibfk_1` FOREIGN KEY (`gsession_id`) REFERENCES `m_gsession` (`gsession_id`),
  ADD CONSTRAINT `m_gsession_deal_ibfk_2` FOREIGN KEY (`deal_holder_user_id`) REFERENCES `m_user` (`user_id`),
  ADD CONSTRAINT `m_gsession_deal_ibfk_3` FOREIGN KEY (`deal_opponent_user_id`) REFERENCES `m_user` (`user_id`);

--
-- Constraints for table `m_gsession_deal_list`
--
ALTER TABLE `m_gsession_deal_list`
  ADD CONSTRAINT `m_gsession_deal_list_ibfk_1` FOREIGN KEY (`deal_id`) REFERENCES `m_gsession_deal` (`deal_id`),
  ADD CONSTRAINT `m_gsession_deal_list_ibfk_2` FOREIGN KEY (`field_id`) REFERENCES `m_cfg_map_field` (`field_id`);

--
-- Constraints for table `m_gsession_log`
--
ALTER TABLE `m_gsession_log`
  ADD CONSTRAINT `m_gsession_log_ibfk_1` FOREIGN KEY (`gsession_id`) REFERENCES `m_gsession` (`gsession_id`),
  ADD CONSTRAINT `m_gsession_log_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `m_user` (`user_id`);

--
-- Constraints for table `m_gsession_map_fgroup`
--
ALTER TABLE `m_gsession_map_fgroup`
  ADD CONSTRAINT `m_gsession_map_fgroup_ibfk_1` FOREIGN KEY (`gsession_id`) REFERENCES `m_gsession` (`gsession_id`),
  ADD CONSTRAINT `m_gsession_map_fgroup_ibfk_2` FOREIGN KEY (`fgroup_id`) REFERENCES `m_cfg_map_fgroup` (`fgroup_id`),
  ADD CONSTRAINT `m_gsession_map_fgroup_ibfk_3` FOREIGN KEY (`map_id`) REFERENCES `m_cfg_map` (`map_id`),
  ADD CONSTRAINT `m_gsession_map_fgroup_ibfk_5` FOREIGN KEY (`fgowner_user_id`) REFERENCES `m_user` (`user_id`);

--
-- Constraints for table `m_gsession_map_field`
--
ALTER TABLE `m_gsession_map_field`
  ADD CONSTRAINT `m_gsession_map_field_ibfk_6` FOREIGN KEY (`fdeal_id`) REFERENCES `m_gsession_deal_list` (`deal_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `m_gsession_map_field_ibfk_1` FOREIGN KEY (`gsession_id`) REFERENCES `m_gsession` (`gsession_id`),
  ADD CONSTRAINT `m_gsession_map_field_ibfk_2` FOREIGN KEY (`map_id`) REFERENCES `m_cfg_map` (`map_id`),
  ADD CONSTRAINT `m_gsession_map_field_ibfk_3` FOREIGN KEY (`field_id`) REFERENCES `m_cfg_map_field` (`field_id`),
  ADD CONSTRAINT `m_gsession_map_field_ibfk_4` FOREIGN KEY (`owner_user_id`) REFERENCES `m_user` (`user_id`),
  ADD CONSTRAINT `m_gsession_map_field_ibfk_5` FOREIGN KEY (`fauct_id`) REFERENCES `m_gsession_auction` (`auct_id`) ON DELETE SET NULL;

--
-- Constraints for table `m_gsession_msg`
--
ALTER TABLE `m_gsession_msg`
  ADD CONSTRAINT `m_gsession_msg_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `m_user` (`user_id`),
  ADD CONSTRAINT `m_gsession_msg_ibfk_2` FOREIGN KEY (`gsession_id`) REFERENCES `m_gsession` (`gsession_id`);

--
-- Constraints for table `m_gsession_user`
--
ALTER TABLE `m_gsession_user`
  ADD CONSTRAINT `m_gsession_user_ibfk_1` FOREIGN KEY (`gsession_id`) REFERENCES `m_gsession` (`gsession_id`),
  ADD CONSTRAINT `m_gsession_user_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `m_user` (`user_id`),
  ADD CONSTRAINT `m_gsession_user_ibfk_3` FOREIGN KEY (`position_field_id`) REFERENCES `m_cfg_map_field` (`field_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
